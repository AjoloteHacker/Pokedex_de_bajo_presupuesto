# 🔴 Pokédex en EC2 (Fedora)

## Estructura del proyecto

```
pokedex/
├── server.js        ← Servidor Node.js
├── public/
│   └── index.html   ← Interfaz de la Pokédex
└── README.md
```

---

## ▶️ Instrucciones para EC2 con Fedora

### 1. Conectarse a la instancia EC2

```bash
ssh -i tu-clave.pem fedora@TU-IP-EC2
```

### 2. Actualizar el sistema

```bash
sudo dnf update -y
```

### 3. Instalar Node.js

```bash
sudo dnf install -y nodejs npm
```

Verificar la instalación:

```bash
node --version
npm --version
```

> **Alternativa con nvm** (para controlar la versión de Node.js):
> ```bash
> curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
> source ~/.bashrc
> nvm install --lts
> ```

### 4. Subir los archivos a EC2

Desde tu **máquina local**, ejecuta:

```bash
scp -i tu-clave.pem -r pokedex/ fedora@TU-IP-EC2:~/
```

### 5. Iniciar el servidor

```bash
cd ~/pokedex
node server.js
```

Verás esto en la terminal:
```
🔴 Pokédex server running!
📡 Local:   http://localhost:3000
🌐 Network: http://0.0.0.0:3000
```

### 6. Abrir en el navegador

```
http://TU-IP-PUBLICA-EC2:3000
```

---

## 🔥 Configurar el Firewall en Fedora (firewalld)

Fedora usa `firewalld` por defecto. Abre el puerto 3000:

```bash
# Abrir el puerto 3000
sudo firewall-cmd --permanent --add-port=3000/tcp

# Recargar el firewall para aplicar cambios
sudo firewall-cmd --reload

# Verificar que el puerto está abierto
sudo firewall-cmd --list-ports
```

---

## 🔒 Configurar el Security Group en AWS

Además del firewall local, debes abrir el puerto en AWS:

1. EC2 → Instancias → tu instancia → **Security Groups**
2. **Inbound rules** → Edit inbound rules
3. Add rule:
   - Type: `Custom TCP`
   - Port range: `3000`
   - Source: `0.0.0.0/0` (o tu IP para más seguridad)

---

## 🔄 Mantener corriendo (opcional)

Para que el servidor siga activo aunque cierres la terminal:

```bash
# Con nohup
nohup node server.js > pokedex.log 2>&1 &
echo $! > pokedex.pid

# Ver logs en tiempo real
tail -f pokedex.log

# Detener el servidor
kill $(cat pokedex.pid)
```

O con PM2 (recomendado):

```bash
# Instalar PM2
sudo npm install -g pm2

# Iniciar la Pokédex
pm2 start server.js --name pokedex

# Guardar la configuración
pm2 save

# Hacer que inicie automáticamente con el sistema
pm2 startup systemd
# (ejecuta el comando que PM2 te indique)

# Otros comandos útiles
pm2 status          # ver estado
pm2 logs pokedex    # ver logs
pm2 stop pokedex    # detener
pm2 restart pokedex # reiniciar
```

---

## 🌐 Cambiar puerto (opcional)

```bash
PORT=8080 node server.js
```

Recuerda también abrir el nuevo puerto en `firewalld` y en el Security Group de AWS.

---

## ✨ Funcionalidades

- 🔍 **Búsqueda** por nombre o número
- 🌍 **Filtro por generación** (Gen I a V)
- 📊 **Modal detallado** con estadísticas, habilidades, peso, altura
- 🔗 **Cadena evolutiva** clickeable
- 🎨 **Colores por tipo** de Pokémon
- 📱 **Responsive** para móvil y escritorio
